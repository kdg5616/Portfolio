package com.ini.board.vo;

import lombok.Data;

@Data
public class BoardTagVO {
    private Long tagId;
    private String tagName;
    // getters/setters
}

